import Recat from "react";
const Places = [
  {
    imgURL:
      "https://t4.ftcdn.net/jpg/03/70/64/43/360_F_370644357_MDF4UXLAXTyyi2OyuK66tWW9cA2f8svL.jpg",

    place: "Europe, Sweden",

    side: "Countryside",
    price: "$1000",
  },
  {
    imgURL:
      "https://assets-news.housing.com/news/wp-content/uploads/2022/02/27121904/featured-compressed-67.jpg",

    place: "Europe, Croatia",

    side: "Beach",
    price: "$500",
  },
  {
    imgURL:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDHm7IwEe-C7w2zrew7eeblUHDk1OaOZvMQw&s",

    place: "Europe, France",

    side: "Casties",
    price: "$1150",
  },
  {
    imgURL:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5oRqPL7lWCsG-1b67jzdiA05Q2S-BtkmgKA&s",

    place: "Europe, Switzerland",

    side: "Lake",
    price: "$2250",
  },
];

export default Places;
